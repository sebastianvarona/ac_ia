const mysql = require('mysql');
const express = require('express');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'ac_ia'
})

const index = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const uno = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const dos = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const tres = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const cuatro = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const cinco = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const seis = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const siete = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const ocho = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const nueve = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}

const diez = (req, res) => {
    db.getConnection((err, connection) => {
        if(err) throw err;

        const sql = `INSERT INTO ecuesta_satisfaccion VALUES (nombre)`;
        connection.query(sql, (err, results, fields) => {
            if(err) throw err;

            // results


            connection.release();
        })
        res.send('Okay');
    })
}